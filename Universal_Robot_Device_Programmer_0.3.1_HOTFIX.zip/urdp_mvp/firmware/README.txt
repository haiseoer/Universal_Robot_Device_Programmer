Đặt firmware ESP32 dạng .bin vào thư mục này.
Chỉ nạp khi đã biết chính xác chip, sơ đồ phân vùng và offset.
Với ESP-IDF, một image ứng dụng thường không đủ để tạo firmware hoàn chỉnh: có thể cần bootloader, partition table và boot_app0 ở các offset riêng. Không tự ý dùng offset 0x1000 cho mọi file.
