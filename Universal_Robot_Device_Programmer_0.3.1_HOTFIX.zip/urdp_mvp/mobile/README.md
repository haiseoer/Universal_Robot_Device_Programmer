# URDP Mobile 0.2.0

A Flutter native companion scaffold for Android and iOS. It implements BLE scanning, connection, Nordic UART Service (NUS) RX/TX, a basic command console, and a stop-command shortcut. It is not yet a signed APK or iOS IPA.

## Build
1. Install Flutter stable and Android Studio / Xcode.
2. `cd mobile/flutter && flutter create . --platforms=android,ios` (this fills the generated platform runner files; keep the supplied `lib/main.dart`, manifest permissions and Info.plist usage strings).
3. `flutter pub get`
4. Android: `flutter build apk --release`.
5. iOS: on macOS with Xcode signing configured, `flutter build ipa --release`.

## BLE protocol
The app currently expects Nordic UART Service UUID `6e400001-b5a3-f393-e0a9-e50e24dcca9e`, RX/write `6e400002-b5a3-f393-e0a9-e50e24dcca9e`, TX/notify `6e400003-b5a3-f393-e0a9-e50e24dcca9e`. Firmware must implement this GATT profile. Other BLE protocols need a device plugin. USB serial/OTG is Android-only and needs a separate USB-host implementation; iOS does not expose universal USB serial access to third-party apps.

App updates should be distributed through Google Play / App Store (or managed enterprise distribution). Robot firmware OTA is separate and requires a board-specific bootloader, signed image, anti-rollback/version checks, power-loss recovery and a physical safe state.

## URDP 0.3.0 mobile additions
The Flutter source now includes companion UI hooks for BLE UART, voice recognition (`speech_to_text`), Vietnamese TTS (`flutter_tts`) and camera capture (`image_picker`). Camera images remain on-device; no vision inference/upload is enabled by default. The mobile voice/camera packages require platform permissions and a native runner generated with Flutter.

Build steps in a Flutter SDK environment:
1. `cd mobile/flutter`
2. `flutter create . --platforms=android,ios` (review/merge generated platform files; do not overwrite the supplied iOS usage descriptions)
3. `flutter pub get`
4. Android: add CAMERA, RECORD_AUDIO, BLUETOOTH_SCAN, BLUETOOTH_CONNECT permissions as required by target SDK, then `flutter build apk --release`.
5. iOS: configure camera/microphone/speech recognition usage descriptions, signing and provisioning in Xcode, then `flutter build ipa --release` on macOS.

No APK/IPA is included in this source release: this environment does not have Flutter/Xcode signing toolchains. iOS device programming remains limited to Apple-supported app deployment and compatible BLE/Wi-Fi device protocols.
