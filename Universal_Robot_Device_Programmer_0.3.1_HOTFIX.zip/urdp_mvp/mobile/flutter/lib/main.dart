import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const URDPMobile());

class URDPMobile extends StatelessWidget {
  const URDPMobile({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'URDP Mobile', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: const Color(0xff1464a5), useMaterial3: true),
    home: const DeviceHome());
}

class DeviceHome extends StatefulWidget { const DeviceHome({super.key}); @override State<DeviceHome> createState()=>_DeviceHomeState(); }
class _DeviceHomeState extends State<DeviceHome> {
  List<ScanResult> results=[]; BluetoothDevice? device; BluetoothCharacteristic? tx; BluetoothCharacteristic? rx;
  final log= <String>[]; final input=TextEditingController(); String face='🙂'; bool scanning=false;
  final stt.SpeechToText speech=stt.SpeechToText(); final FlutterTts tts=FlutterTts(); final ImagePicker picker=ImagePicker(); bool listening=false; XFile? capturedImage;
  // Nordic UART Service. Robot firmware must implement this BLE GATT profile or provide a matching plugin.
  final Guid serviceId=Guid('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
  final Guid rxId=Guid('6e400002-b5a3-f393-e0a9-e50e24dcca9e');
  final Guid txId=Guid('6e400003-b5a3-f393-e0a9-e50e24dcca9e');
  void add(String s){if(mounted)setState(()=>log.add(s));}
  Future<void> scan() async {
    await [Permission.bluetoothScan,Permission.bluetoothConnect,Permission.locationWhenInUse].request();
    setState(()=>scanning=true); results=[];
    try { await FlutterBluePlus.startScan(timeout: const Duration(seconds:8));
      FlutterBluePlus.scanResults.listen((r){if(mounted)setState(()=>results=r);});
      await Future.delayed(const Duration(seconds:8));
    } catch(e){add('Scan error: $e');} finally {if(mounted)setState(()=>scanning=false);}
  }
  Future<void> connect(BluetoothDevice d) async {
    try { await d.connect(timeout: const Duration(seconds:12), autoConnect:false); device=d;
      final services=await d.discoverServices();
      for(final s in services){if(s.serviceUuid==serviceId){for(final c in s.characteristics){if(c.characteristicUuid==rxId)tx=c;if(c.characteristicUuid==txId)rx=c;}}}
      if(rx!=null){await rx!.setNotifyValue(true);rx!.onValueReceived.listen((v)=>add('RX  ${utf8.decode(v,allowMalformed:true)}'));}
      add('Connected: ${d.platformName.isEmpty?d.remoteId.str:d.platformName}');setState((){});
    } catch(e){add('Connect error: $e');}
  }
  Future<void> send() async {if(tx==null){add('Chưa kết nối dịch vụ UART BLE tương thích.');return;} final value=input.text; if(value.isEmpty)return;
    try{await tx!.write([...utf8.encode('$value\n')], withoutResponse:false);add('TX  $value');input.clear();}catch(e){add('TX error: $e');}}
  Future<void> startVoice() async {try{final ok=await speech.initialize();if(!ok){add('Speech recognition không khả dụng trên thiết bị.');return;}setState(()=>listening=true);speech.listen(localeId:'vi_VN',onResult:(r){input.text=r.recognizedWords;if(r.finalResult){send();}});}catch(e){add('Voice error: $e');}}
  Future<void> stopVoice() async {await speech.stop();if(mounted)setState(()=>listening=false);}
  Future<void> captureCamera() async {try{final x=await picker.pickImage(source:ImageSource.camera,imageQuality:80,maxWidth:1600);if(x!=null){capturedImage=x;add('Đã chụp ảnh: ${x.name} (${await x.length()} bytes). Vision model/server endpoint cần cấu hình riêng.');setState((){});}}catch(e){add('Camera error: $e');}}
  Future<void> speak(String value) async {try{await tts.setLanguage('vi-VN');await tts.speak(value);}catch(e){add('TTS error: $e');}}
  Future<void> stopRobot() async {await stopVoice();face='🛑'; if(tx!=null){try{await tx!.write(utf8.encode('{"cmd":"stop"}\n'));}catch(_){}} add('Đã gửi lệnh dừng nếu thiết bị nhận UART BLE.');setState((){});}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('URDP Mobile'),subtitle:const Text('Robot · BLE · Serial companion')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Text(face,style:const TextStyle(fontSize:48)),const SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(device?.platformName??'Chưa kết nối robot',style:Theme.of(context).textTheme.titleMedium),const Text('BLE UART · Nordic UART Service')]))]))),
      Wrap(spacing:8,children:[FilledButton.icon(onPressed:scanning?null:scan,icon:const Icon(Icons.bluetooth_searching),label:Text(scanning?'Đang quét':'Quét BLE')),OutlinedButton.icon(onPressed:listening?stopVoice:startVoice,icon:const Icon(Icons.mic),label:Text(listening?'Tắt mic':'Voice')),OutlinedButton.icon(onPressed:captureCamera,icon:const Icon(Icons.camera_alt),label:const Text('Camera')),OutlinedButton.icon(onPressed:stopRobot,icon:const Icon(Icons.stop_circle),label:const Text('Dừng khẩn cấp'))]),
      if(capturedImage!=null) ListTile(leading:const Icon(Icons.image),title:Text(capturedImage!.name),subtitle:const Text('Ảnh chụp cục bộ; chưa gửi lên server/model vision.')), 
      const SizedBox(height:12),Text('Thiết bị tìm thấy (${results.length})',style:Theme.of(context).textTheme.titleMedium),
      ...results.map((r)=>ListTile(title:Text(r.device.platformName.isEmpty?r.device.remoteId.str:r.device.platformName),subtitle:Text(r.device.remoteId.str),trailing:Text('${r.rssi} dBm'),onTap:()=>connect(r.device))),
      const Divider(),TextField(controller:input,decoration:InputDecoration(labelText:'Gửi lệnh / Serial TX',suffixIcon:IconButton(onPressed:send,icon:const Icon(Icons.send)))),
      const SizedBox(height:8),Text('Serial RX / Nhật ký',style:Theme.of(context).textTheme.titleMedium),Container(height:260,padding:const EdgeInsets.all(10),color:Colors.black87,child:ListView(children:log.map((s)=>Text(s,style:const TextStyle(color:Colors.greenAccent,fontFamily:'monospace'))).toList())),
      const SizedBox(height:12),const Text('Voice/camera chạy trên thiết bị; gửi lệnh UART BLE chỉ khi robot hỗ trợ giao thức tương ứng. Điều hướng và autonomy vật lý cần ROS 2/firmware adapter, cảm biến, watchdog và E-stop phần cứng. App update qua store; firmware OTA phải xác minh chữ ký và model.'),
    ]));
}
