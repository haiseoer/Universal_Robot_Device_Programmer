from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get('/api/health')
    assert r.status_code == 200 and r.json()['ok']

def test_flash_requires_confirmation():
    r = client.post('/api/flash/esp32', json={'port':'COM1','firmware':'firmware/test.bin','chip':'esp32','offset':'0x1000','baud':460800,'confirm':False})
    assert r.status_code == 400

def test_firmware_path_restricted():
    r = client.post('/api/flash/esp32', json={'port':'COM1','firmware':'../README.md','chip':'esp32','offset':'0x1000','baud':460800,'confirm':True})
    assert r.status_code == 400
