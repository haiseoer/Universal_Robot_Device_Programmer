from app.robot.behavior import BehaviorEngine
from app.updates import verify_manifest, UpdateError

def test_robot_intent_and_estop():
    bot=BehaviorEngine()
    result=bot.interpret('xin chào')
    assert result['accepted'] and result['state']['expression']=='😄'
    stopped=bot.stop()
    assert stopped['estop'] is True
    assert bot.interpret('xin chào')['accepted'] is False
    assert bot.reset()['estop'] is False

def test_unknown_intent_does_not_move():
    bot=BehaviorEngine()
    result=bot.interpret('hãy lái xe ra đường')
    assert result['accepted'] is False
    assert result['state']['action']=='ask_clarification'

def test_update_requires_https_and_key():
    try:
        verify_manifest({'version':'0.2.1','url':'http://example.com/a.zip','sha256':'0'*64,'signature':'AA=='}, 'AA==')
    except UpdateError as e:
        assert 'HTTPS' in str(e)
    else: assert False
