from app.robot.navigation import astar
from app.robot.autonomy import AutonomySupervisor
from app.hardware.registry import list_adapters

def test_astar_path_avoids_obstacle():
    grid=[[0,0,0],[1,1,0],[0,0,0]]
    path=astar(grid,(0,0),(2,2))
    assert path[0]==(0,0) and path[-1]==(2,2)
    assert all(not grid[r][c] for r,c in path)

def test_astar_no_path():
    assert astar([[0,1],[1,0]],(0,0),(1,1)) == []

def test_autonomy_requires_hardware_estop_for_real_mode():
    a=AutonomySupervisor()
    out=a.enable(hardware_estop=False,simulation=False)
    assert not out['accepted']
    assert not a.state.enabled

def test_autonomy_simulation_and_estop_latch():
    a=AutonomySupervisor()
    assert a.enable(simulation=True)['accepted']
    assert a.stop()['estop']
    assert not a.enable(simulation=True)['accepted']
    assert not a.reset()['estop']

def test_adapter_registry_includes_esp32_and_expansion_points():
    ids={x['id'] for x in list_adapters()}
    assert {'esp32-esptool','stm32-openocd','rp2040-picotool','nordic-west'} <= ids
