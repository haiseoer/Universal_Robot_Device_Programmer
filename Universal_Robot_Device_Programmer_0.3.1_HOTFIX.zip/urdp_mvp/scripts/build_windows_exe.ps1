$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
python -m venv .venv
. .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --clean --name "UniversalRobotDeviceProgrammer" --onedir --add-data "app/templates;app/templates" --add-data "app/static;app/static" --add-data "firmware;firmware" launcher.py
Write-Host "Build output: dist\UniversalRobotDeviceProgrammer"
Write-Host "For a signed installer, package this folder with Inno Setup. See docs/INSTALL.md."
