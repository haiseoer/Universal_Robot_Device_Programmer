# Hardware compatibility matrix — URDP 0.3.0

| Family | Interface | Artifact | 0.3.0 state |
|---|---|---|---|
| ESP32 / S2 / S3 / C2 / C3 / C6 / H2 | USB-UART | BIN | Active flasher in this project; verify exact module and offsets |
| Arduino AVR/SAMD and supported cores | USB / ISP | HEX/ELF/BIN | Arduino CLI detection only; board FQBN + compile/upload adapter pending |
| STM32 | SWD/JTAG/UART bootloader | ELF/HEX/BIN | Adapter descriptor; OpenOCD/ST-LINK integration pending |
| RP2040/RP2350 | USB BOOTSEL/SWD | UF2/ELF/BIN | Adapter descriptor; picotool integration pending |
| Nordic nRF52/53/91 | SWD/USB DFU/BLE | HEX/ZIP/BIN | Adapter descriptor; west/nrfjprog/DFU integration pending |
| NXP/Microchip/TI/Renesas/Silicon Labs | Vendor-specific | Vendor-specific | Plugin integration point only |
| Raspberry Pi Linux / Jetson | SSH/ADB-like management, OS image | IMG/DEB/container | Not a microcontroller flash target; separate provisioning plugin required |
| Android phones/tablets | ADB/Fastboot with authorization | APK/IMG | Not general robot mainboard flashing; user authorization and OEM restrictions apply |
| iPhone/iPad | Apple-supported deployment | IPA | No unrestricted third-party firmware flashing; Xcode/signing/Apple policies apply |

"All" means the registry can be extended to these families; it does not mean all adapters are already implemented or all devices can be flashed from one interface.
