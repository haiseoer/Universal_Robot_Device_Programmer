# URDP 0.3.0 — Architecture and module contract

## Design

URDP is a local-first extensible workstation, not a universal protocol converter. Mainboards differ in boot ROM, debug probe, voltage, flash layout, signed boot policy and vendor toolchains. The core therefore talks to capability-described adapters.

```text
Desktop / Web UI / Flutter companion
              |
       URDP Core API (FastAPI)
   +----------+-----------+----------------+
   | Device/Transport     | Project/Build  | Signed OTA
   | USB/UART/BLE         | Firmware       | Ed25519 + SHA256
   +----------+-----------+----------------+
              |
       Hardware Adapter Registry
   ESP32 | Arduino CLI | STM32/OpenOCD | RP2040 | Nordic | Vendor plugins
              |
        Robot Runtime (separate)
   Voice I/O | Vision | Navigation | Autonomy Supervisor
             Emotion/Behavior | ROS 2 boundary
              |
   Robot-specific controllers / sensors / actuators
              |
   Independent physical safety chain (E-stop, motor power cut)
```

## Modules delivered in 0.3.0

| Module | Endpoint / file | State |
|---|---|---|
| Adapter registry | `GET /api/hardware/adapters`, `app/hardware/registry.py` | Descriptors for ESP32, Arduino CLI, STM32/OpenOCD, RP2040, Nordic and vendor plugin point |
| Voice | `GET /api/robot/voice/capabilities` | Browser speech recognition + speech synthesis capability boundary; client microphone, no server audio storage |
| Vision intake | `POST /api/robot/vision/inspect` | In-memory image validation, 8 MB cap; no object recognition model yet |
| Navigation | `POST /api/robot/navigation/plan` | A* grid planner, max 100x100, simulation only |
| Autonomy supervisor | `/api/robot/autonomy/*` | Safety latch, simulation mode; real mode rejects without hardware E-stop and fresh heartbeat |
| ROS 2 | `GET /api/robot/ros2/status` | Optional dependency detection and topic contract; no active ROS node transport yet |
| Emotion | existing `app/robot/behavior.py` | Deterministic expression and intent mapping, not sentience |
| OTA | `/api/updates/check` | Existing signed Ed25519 manifest verification; no automatic installation or device OTA transport |

## Adapter contract

Each adapter descriptor in `app/hardware/adapters/*.json` declares `id`, `name`, `family`, `status`, `interfaces`, `artifacts`, optional `tool`, and notes. A production adapter must implement discovery, identify, compile, flash, verify, recovery and safety preflight. Tool execution must use argument arrays (never shell strings), allowlisted paths, timeouts, and explicit user confirmation. Only ESP32-family `.bin` flashing is currently wired to a real flash operation.

## API quick start

- `GET /api/architecture` is not used; use `GET /api/v030/architecture`.
- `GET /api/hardware/adapters`
- `GET /api/robot/voice/capabilities`
- `POST /api/robot/vision/inspect` with raw image bytes and `Content-Type: image/jpeg` or PNG.
- `POST /api/robot/navigation/plan` JSON: `{"grid":[[0,0],[1,0]],"start":[0,0],"goal":[1,1]}`.
- `POST /api/robot/autonomy/enable` JSON: `{"simulation":true}`.
- `POST /api/robot/autonomy/heartbeat`, `/stop`, `/reset`.
- `GET /api/robot/ros2/status`.

## Production safety requirements

1. Physical E-stop must interrupt motor/actuator power independently of URDP, OS, network and AI.
2. Motion commands require robot-specific limits, watchdog, dead-man/manual override, collision sensing, localization confidence and stale-data timeout.
3. Vision and voice outputs are untrusted suggestions; a policy layer validates every action.
4. Firmware update must verify publisher signature and artifact hash, target hardware ID, version compatibility, power state and rollback/recovery plan.
5. Do not enable autonomous physical movement until hardware-in-loop testing and risk assessment are complete.
