# Secure update configuration

The desktop updater checks a publisher-controlled HTTPS manifest. Configure:

- `URDP_UPDATE_MANIFEST_URL`: fixed HTTPS URL for the JSON manifest.
- `URDP_UPDATE_PUBLIC_KEY`: base64-encoded 32-byte Ed25519 public key.

Manifest fields: `version`, `url` (HTTPS), `sha256` (64 lowercase hex characters), `signature` (base64 Ed25519 signature). Signature input is UTF-8 JSON with sorted keys and compact separators for exactly `{ "version": ..., "url": ..., "sha256": ... }` (without whitespace, actual serialization by Python `json.dumps(..., sort_keys=True, separators=(',', ':'))`).

The current implementation verifies the manifest only. It does not install desktop updates or flash device firmware. Do not embed private signing keys in the application. Build and sign releases in a controlled CI pipeline. Firmware images need separate per-board signing/verification and bootloader rollback protection.
