# Cài đặt và chạy URDP MVP 0.1.0

## Windows 10/11
1. Cài Python 3.10+ (đánh dấu Add Python to PATH).
2. Giải nén gói dự án.
3. Chạy `run_windows.bat`.
4. Mở `http://127.0.0.1:8000` nếu trình duyệt không tự mở.
5. Kết nối bo ESP32 bằng cáp USB dữ liệu; cài driver USB-UART phù hợp (CP210x, CH340, FTDI tùy board).
6. Đặt file `.bin` trong `firmware/`, quét cổng, chọn chip/port/baud/offset, xác nhận rồi nạp.

## macOS / Linux
Cài Python 3.10+, quyền truy cập serial phù hợp, chạy `./run_mac_linux.sh`, sau đó mở `http://127.0.0.1:8000`.

## Đóng gói Windows EXE
Mở PowerShell tại thư mục dự án và chạy:
`powershell -ExecutionPolicy Bypass -File scripts/build_windows_exe.ps1`

Script tạo thư mục `dist/`. Đây là bản đóng gói thử nghiệm, chưa phải installer ký số. Có thể dùng Inno Setup để tạo setup.exe sau khi kiểm thử trên máy Windows sạch.

## Lưu ý nạp ESP32
- Nạp firmware là thao tác có rủi ro. Luôn xác nhận đúng chip, cổng, file, offset và sơ đồ phân vùng.
- Endpoint MVP chỉ ghi một file BIN tại offset người dùng nhập; không tự suy luận layout ESP-IDF nhiều phân vùng.
- Không tự động xóa flash; không đọc/bypass bảo vệ flash hoặc khóa bảo mật.
- Nếu chip bật Secure Boot/Flash Encryption hoặc bootloader khóa, quy trình nạp có thể cần khóa/chữ ký/quyền của nhà sản xuất.

## Điện thoại
Giao diện tương thích màn hình di động và có manifest PWA. Tuy nhiên backend USB/Serial cần chạy trên máy chủ cục bộ. iOS không cho phép một web app truy cập tùy ý cổng USB/serial; Android OTG cần ứng dụng native/USB Host phù hợp. Bản này chưa phải ứng dụng APK/IPA và không nạp firmware trực tiếp từ điện thoại.

## Tạo file cài đặt Windows dạng Setup.exe
Sau khi chạy thành công `scripts/build_windows_exe.ps1` trên Windows:
1. Cài Inno Setup 6.
2. Mở `installer/URDP.iss` bằng Inno Setup Compiler.
3. Compile để tạo `installer-output/URDP-Setup-0.1.0.exe`.

MVP hiện cung cấp mã nguồn và script tạo installer; file EXE/Setup.exe chưa được build trong môi trường Linux này.


### Nếu nâng cấp từ 0.3.0 lên 0.3.1

Giải nén bản 0.3.1 vào thư mục mới. Có thể giữ lại thư mục `.venv` hiện tại nếu không đổi Python; nếu vẫn phát sinh lỗi phụ thuộc, xóa `.venv` rồi chạy `INSTALL.bat` để tạo môi trường sạch.
