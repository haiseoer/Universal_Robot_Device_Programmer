# URDP roadmap

## 0.2.0 implemented in this source package
- Bidirectional WebSocket serial monitor (one port per session, UTF-8 text, selectable baud).
- Flutter Android/iOS companion source scaffold with BLE UART NUS scan/connect/RX/TX.
- Deterministic intent demo with expressions, unknown-intent rejection and emergency-stop latch.
- HTTPS update-manifest check with pinned Ed25519 signature and SHA-256 integrity verification.

## Next engineering milestones
1. Add native Android USB Host / OTG serial using a reviewed USB-serial library and device permission flow.
2. Add board-specific BLE/Wi-Fi/USB protocol plugins and hardware-in-loop tests.
3. Add secure device OTA: signed firmware, device identity, TLS, anti-rollback, A/B slots where supported, power-fail recovery, staged rollout and recovery mode.
4. Add real robot autonomy only after defining chassis, motor drivers, encoders, IMU, range sensors, compute board, ROS 2 / micro-ROS bridge, navigation stack and physical emergency-stop circuit.
5. Publish app binaries after platform signing, privacy review, permissions review and store compliance.

## Important limits
- “Emotion” is a programmed expression/state, not consciousness or subjective feeling.
- Natural language intent mapping is deliberately limited. Unknown requests do not cause movement.
- Software stop is not a substitute for a hardwired motor power cut / emergency stop.
- iOS supports BLE and network workflows within Apple APIs; it is not a universal USB firmware flasher.
- A universal updater cannot safely flash every robot/mainboard. Each device family needs a verified driver, bootloader and recovery procedure.
