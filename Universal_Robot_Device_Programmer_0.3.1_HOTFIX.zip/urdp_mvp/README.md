# Universal Robot & Device Programmer (URDP) — MVP 0.1.0

Local-first embedded programming workspace inspired by the supplied ESP32 AI Coder & Web Serial Hub video.

## Included
- Responsive Vietnamese dashboard.
- Local FastAPI backend.
- USB/Serial port discovery.
- ESP32-family `.bin` flashing through esptool with explicit confirmation.
- Firmware file listing, starter sketch editor, export/copy, capability roadmap.
- Windows setup/launch scripts, macOS/Linux launch script, Windows PyInstaller + Inno Setup installer scripts.
- PWA manifest for installable mobile web shell.

## Quick start
Windows: double-click `run_windows.bat`.
macOS/Linux: `./run_mac_linux.sh`.
Then visit `http://127.0.0.1:8000`.

See `docs/INSTALL.md` and `docs/ROADMAP.md`.

## Current limits
Only ESP32-family single-BIN flash is enabled. Arduino/STM32/RP2040/Nordic/NXP and phone workflows are roadmap items, not implemented drivers. The code editor's sample generator is a static template, not an AI model or compiler. Serial monitor transmit/receive is not yet implemented. Android/iOS native packages are not included in this MVP.

## 0.3.1 additions
- Two-way WebSocket serial console (`/ws/serial`) with TX/RX.
- Robot interaction demo (`/api/robot/*`) with predefined intents, facial-expression states and emergency-stop latch.
- Internet update manifest check (`/api/updates/check`) requiring HTTPS + Ed25519 signature; no unattended installation.
- Flutter Android/iOS BLE companion source under `mobile/flutter` (not prebuilt APK/IPA).

See `mobile/README.md`, `docs/SECURITY_OTA.md`, and `docs/ROADMAP.md`. Robot expressions are programmed behaviors, not consciousness. Physical movement requires a robot-specific safety controller and hardwired emergency stop.


## URDP 0.3.1 additions
- Adapter registry for ESP32, Arduino CLI, STM32/OpenOCD, RP2040/picotool, Nordic/west and vendor plugin points.
- Robot runtime modules: browser voice I/O, privacy-first image intake, A* grid navigation simulation, safety-gated autonomy supervisor, ROS 2 integration boundary.
- New API docs: `docs/ARCHITECTURE_030.md` and `docs/HARDWARE_MATRIX_030.md`.
- Run tests with `python -m pytest -q`.

Important: only ESP32-family firmware flashing is wired to a real flasher in this build. Other board entries are adapter descriptors/integration points, not claimed working flashers. Navigation and autonomy are simulation-only.


## URDP 0.3.1 – hotfix giao diện

- Sửa lời gọi `Jinja2Templates.TemplateResponse` theo API hiện hành của Starlette (`request=`, `name=`, `context=`).
- Khắc phục lỗi HTTP 500 tại trang chủ do truyền đối số positional theo chữ ký cũ.
- Giữ nguyên các module và API của bản 0.3.0.
