@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo UNIVERSAL ROBOT & DEVICE PROGRAMMER - SETUP
echo ================================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10+ is required. Install it from python.org and enable PATH.
  pause
  exit /b 1
)
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
  echo Dependency installation failed. Check internet access and retry.
  pause
  exit /b 1
)
echo Setup completed. Run run_windows.bat to start the application.
pause
