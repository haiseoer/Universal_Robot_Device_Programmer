from pathlib import Path
import os, sys, json, subprocess, threading, time
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(title="Universal Robot & Device Programmer", version="0.3.1")
app.mount('/static', StaticFiles(directory=str(ROOT/'app'/'static')), name='static')
templates = Jinja2Templates(directory=str(ROOT/'app'/'templates'))

class FlashRequest(BaseModel):
    port: str = Field(min_length=1, max_length=128)
    firmware: str = Field(min_length=1, max_length=1024)
    chip: str = "esp32"
    offset: str = Field(default="0x1000", pattern=r"^0x[0-9A-Fa-f]{1,8}$")
    baud: int = Field(default=460800, ge=9600, le=2000000)
    confirm: bool = False

@app.get('/', response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name='index.html', context={})

@app.get('/api/health')
def health():
    return {'ok': True, 'name': app.title, 'version': app.version}

@app.get('/api/ports')
def ports():
    try:
        from serial.tools import list_ports
        found = [{'device': p.device, 'description': p.description or 'Serial device', 'vid': p.vid, 'pid': p.pid} for p in list_ports.comports()]
        return {'ports': found}
    except Exception as e:
        return {'ports': [], 'warning': str(e)}

@app.get('/api/firmware')
def firmware_files():
    folder = ROOT/'firmware'
    return {'files': [{'name': p.name, 'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size} for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.bin','.hex','.uf2','.elf')]}

@app.post('/api/flash/esp32')
def flash_esp32(req: FlashRequest):
    if not req.confirm:
        raise HTTPException(400, 'Cần xác nhận đúng bo mạch, firmware và địa chỉ flash trước khi nạp.')
    if req.chip.lower() not in ('esp32','esp32s2','esp32s3','esp32c2','esp32c3','esp32c6','esp32h2'):
        raise HTTPException(400, 'MVP hiện chỉ bật bộ nạp ESP32-family; chip này chưa được xác nhận hỗ trợ.')
    fw = (ROOT/req.firmware).resolve()
    if ROOT/'firmware' not in fw.parents or not fw.is_file() or fw.suffix.lower() != '.bin':
        raise HTTPException(400, 'Chỉ chấp nhận file .bin nằm trong thư mục firmware của dự án.')
    try:
        import serial.tools.list_ports
        valid = {p.device for p in serial.tools.list_ports.comports()}
    except Exception:
        valid = set()
    if req.port not in valid:
        raise HTTPException(400, 'Không tìm thấy cổng COM/serial đã chọn. Hãy kết nối lại thiết bị và quét cổng.')
    cmd = [sys.executable, '-m', 'esptool', '--chip', req.chip, '--port', req.port, '--baud', str(req.baud), 'write-flash', req.offset, str(fw)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=240, cwd=str(ROOT))
    except subprocess.TimeoutExpired:
        raise HTTPException(504, 'Quá thời gian chờ nạp. Kiểm tra cáp, nguồn và chế độ bootloader.')
    return {'success': result.returncode == 0, 'command': cmd[:-1] + [fw.name], 'stdout': result.stdout[-12000:], 'stderr': result.stderr[-6000:], 'returncode': result.returncode,
            'message': 'Nạp hoàn tất.' if result.returncode == 0 else 'Nạp thất bại. Xem log để kiểm tra.'}

@app.post('/api/compile/arduino')
def compile_arduino(payload: dict):
    # Safe MVP placeholder: compilation is enabled only when a local arduino-cli project is configured.
    project = payload.get('project', '')
    if not project:
        raise HTTPException(400, 'Chưa chọn thư mục sketch Arduino.')
    path = Path(project).expanduser().resolve()
    if not path.exists() or not path.is_dir():
        raise HTTPException(400, 'Thư mục sketch không tồn tại.')
    exe = 'arduino-cli.exe' if os.name == 'nt' else 'arduino-cli'
    try:
        version = subprocess.run([exe, 'version'], capture_output=True, text=True, timeout=10)
    except Exception:
        raise HTTPException(503, 'Chưa cài Arduino CLI. Xem hướng dẫn trong docs/INSTALL.md.')
    return {'available': version.returncode == 0, 'message': 'Arduino CLI đã được phát hiện. Tính năng compile theo board sẽ được cấu hình ở bản kế tiếp.', 'version': version.stdout.strip()}

@app.get('/api/capabilities')
def capabilities():
    return {'active': [{'family':'ESP32','models':['ESP32','ESP32-S2','ESP32-S3','ESP32-C2','ESP32-C3','ESP32-C6','ESP32-H2'],'method':'esptool.py','status':'enabled'}],
            'planned': [{'family':'Arduino AVR / SAMD','method':'arduino-cli / avrdude'}, {'family':'STM32','method':'STM32CubeProgrammer / OpenOCD'}, {'family':'RP2040 / RP2350','method':'UF2 / picotool'}, {'family':'Nordic nRF','method':'nrfjprog / west'}, {'family':'NXP / Renesas / TI / Microchip','method':'vendor tools / OpenOCD'}, {'family':'Android','method':'ADB / Fastboot where authorized'}, {'family':'iOS','method':'Apple-supported app/device interfaces'}]}

# URDP 0.2.0 extensions: bidirectional serial, signed update checks, safe robot demo.
from fastapi import WebSocket, WebSocketDisconnect
from app.robot.behavior import BehaviorEngine
robot_engine = BehaviorEngine()

@app.websocket('/ws/serial')
async def serial_socket(ws: WebSocket):
    """One WebSocket owns one serial port; text frames are transmitted as UTF-8."""
    await ws.accept()
    ser = None
    try:
        port = ws.query_params.get('port','')
        baud = int(ws.query_params.get('baud','115200'))
        if not (9600 <= baud <= 2000000):
            await ws.send_json({'type':'error','message':'Baud rate ngoài giới hạn.'}); await ws.close(); return
        from serial import Serial
        from serial.tools import list_ports
        if port not in {p.device for p in list_ports.comports()}:
            await ws.send_json({'type':'error','message':'Cổng serial không tồn tại.'}); await ws.close(); return
        ser = Serial(port, baudrate=baud, timeout=0.15, write_timeout=2)
        await ws.send_json({'type':'status','message':f'Đã kết nối {port} @ {baud}'})
        import asyncio
        async def reader():
            while True:
                raw = await asyncio.to_thread(ser.readline)
                if raw:
                    await ws.send_json({'type':'rx','data':raw.decode('utf-8',errors='replace').rstrip('\r\n')})
                else:
                    await asyncio.sleep(0.02)
        async def writer():
            while True:
                msg = await ws.receive_json()
                if msg.get('type') == 'tx':
                    data = str(msg.get('data',''))
                    if len(data) > 4096: await ws.send_json({'type':'error','message':'Dữ liệu gửi vượt 4096 ký tự.'}); continue
                    ending = msg.get('ending','newline')
                    suffix = {'none':'','lf':'\n','cr':'\r','newline':'\r\n'}.get(ending)
                    if suffix is None: suffix='\r\n'
                    await asyncio.to_thread(ser.write, (data+suffix).encode('utf-8'))
                    await ws.send_json({'type':'tx','data':data})
        tasks=[asyncio.create_task(reader()),asyncio.create_task(writer())]
        done,pending=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
        for task in pending: task.cancel()
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try: await ws.send_json({'type':'error','message':str(e)[:500]})
        except Exception: pass
    finally:
        if ser:
            try: ser.close()
            except Exception: pass

@app.get('/api/robot/state')
def robot_state():
    from dataclasses import asdict
    return asdict(robot_engine.state)

@app.post('/api/robot/intent')
def robot_intent(payload: dict):
    text_value = payload.get('text','')
    if not isinstance(text_value,str): raise HTTPException(400,'Lệnh phải là văn bản.')
    return robot_engine.interpret(text_value)

@app.post('/api/robot/stop')
def robot_stop():
    return robot_engine.stop()

@app.post('/api/robot/reset')
def robot_reset():
    return robot_engine.reset()

@app.get('/api/updates/check')
def check_updates():
    """Fetch only the publisher-configured HTTPS manifest and verify Ed25519."""
    import os
    from urllib.parse import urlparse
    from urllib.request import urlopen
    from app.updates import verify_manifest, UpdateError
    manifest_url=os.getenv('URDP_UPDATE_MANIFEST_URL','')
    if urlparse(manifest_url).scheme != 'https':
        raise HTTPException(503,'Chưa cấu hình URDP_UPDATE_MANIFEST_URL HTTPS.')
    try:
        with urlopen(manifest_url,timeout=12) as response:
            if response.status != 200: raise UpdateError('Không tải được manifest cập nhật.')
            data=json.loads(response.read(128*1024))
        verified=verify_manifest(data)
        verified['current_version']=app.version
        verified['update_available']=verified['version'] != app.version
        return verified
    except Exception as e:
        raise HTTPException(502,str(e)[:400])


# URDP 0.3.0: plugin registry, navigation simulation, autonomy supervisor,
# privacy-first vision intake, voice capability bridge and optional ROS 2 status.
from app.hardware.registry import list_adapters, get_adapter
from app.robot.navigation import astar
from app.robot.autonomy import AutonomySupervisor
from app.robot.ros2_bridge import status as ros2_status
from app.services.voice import capabilities as voice_capabilities
from app.services.vision import inspect_image
from starlette.requests import Request

autonomy_supervisor = AutonomySupervisor()


@app.get('/api/v030/architecture')
def architecture():
    return {'version':'0.3.0','layers':[
        {'id':'core','name':'URDP Core','modules':['device registry','plugin loader','serial transport','firmware pipeline','signed OTA','audit log']},
        {'id':'robot','name':'Robot Runtime','modules':['voice I/O','camera/vision','navigation','autonomy supervisor','emotion/behavior','ROS 2 bridge']},
        {'id':'hardware','name':'Hardware Adapter Layer','modules':['ESP32','Arduino CLI','STM32/OpenOCD','RP2040/picotool','Nordic/west','vendor plugins']}
    ],'principle':'Capability-based adapters; no universal flashing protocol exists.'}

@app.get('/api/hardware/adapters')
def hardware_adapters():
    return {'adapters':list_adapters()}

@app.get('/api/robot/voice/capabilities')
def robot_voice_capabilities():
    return voice_capabilities()

@app.post('/api/robot/vision/inspect')
async def robot_vision_inspect(request: Request):
    blob=await request.body()
    try: return inspect_image(blob)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post('/api/robot/navigation/plan')
def navigation_plan(payload: dict):
    grid=payload.get('grid'); start=payload.get('start'); goal=payload.get('goal')
    if not isinstance(grid,list) or len(grid)>100 or any(not isinstance(r,list) or len(r)>100 for r in grid):
        raise HTTPException(400,'Grid phải là ma trận tối đa 100x100.')
    try:
        path=astar(grid,tuple(start),tuple(goal))
        return {'found':bool(path),'path':path,'steps':max(0,len(path)-1),'mode':'simulation-only'}
    except (ValueError,TypeError,IndexError) as e: raise HTTPException(400,str(e))

@app.get('/api/robot/autonomy/state')
def autonomy_state():
    from dataclasses import asdict
    return asdict(autonomy_supervisor.state)

@app.post('/api/robot/autonomy/enable')
def autonomy_enable(payload: dict):
    return autonomy_supervisor.enable(hardware_estop=bool(payload.get('hardware_estop',False)),simulation=bool(payload.get('simulation',True)))

@app.post('/api/robot/autonomy/heartbeat')
def autonomy_heartbeat():
    return autonomy_supervisor.sensor_heartbeat()

@app.post('/api/robot/autonomy/stop')
def autonomy_stop():
    return autonomy_supervisor.stop()

@app.post('/api/robot/autonomy/reset')
def autonomy_reset():
    return autonomy_supervisor.reset()

@app.get('/api/robot/ros2/status')
def robot_ros2_status():
    return ros2_status()
