"""Deterministic, safety-bounded robot behavior demo (not sentient AI)."""
from dataclasses import dataclass, asdict
from enum import Enum

class Emotion(str, Enum):
    NEUTRAL = 'neutral'
    HAPPY = 'happy'
    CURIOUS = 'curious'
    CONFUSED = 'confused'
    SLEEPY = 'sleepy'
    ALERT = 'alert'

@dataclass
class RobotState:
    mode: str = 'idle'
    emotion: Emotion = Emotion.NEUTRAL
    expression: str = '🙂'
    action: str = 'standby'
    speech: str = 'Xin chào! Tôi đang chờ lệnh.'
    estop: bool = False

class BehaviorEngine:
    """Small intent map; unknown natural-language requests never cause motion."""
    def __init__(self): self.state = RobotState()
    def stop(self):
        self.state.estop = True; self.state.mode = 'stopped'; self.state.action = 'stop'
        self.state.emotion = Emotion.ALERT; self.state.expression = '🛑'; self.state.speech = 'Đã dừng khẩn cấp.'
        return asdict(self.state)
    def reset(self):
        self.state = RobotState(); self.state.speech = 'Đã xóa trạng thái dừng. Chờ lệnh mới.'
        return asdict(self.state)
    def interpret(self, text: str):
        t = (text or '').strip().lower()
        if not t or len(t) > 300: return {'accepted':False,'reason':'Lệnh trống hoặc quá dài.','state':asdict(self.state)}
        if self.state.estop: return {'accepted':False,'reason':'Đang khóa an toàn. Hãy reset trước.','state':asdict(self.state)}
        # Only safe demo actions; physical motion requires a separate hardware safety controller.
        if any(w in t for w in ('xin chào','hello','chào')):
            self.state.emotion=Emotion.HAPPY; self.state.expression='😄'; self.state.action='wave_demo'; self.state.speech='Xin chào! Rất vui được gặp bạn.'
        elif any(w in t for w in ('bạn là ai','giới thiệu','who are you')):
            self.state.emotion=Emotion.CURIOUS; self.state.expression='🤖'; self.state.action='look_at_user'; self.state.speech='Tôi là robot được lập trình để tương tác và hỗ trợ.'
        elif any(w in t for w in ('ngủ','nghỉ','sleep')):
            self.state.emotion=Emotion.SLEEPY; self.state.expression='😴'; self.state.action='sleep_pose'; self.state.speech='Tôi sẽ chuyển sang chế độ nghỉ.'
        elif any(w in t for w in ('dừng','stop','đứng yên')):
            self.state.action='stop'; self.state.mode='idle'; self.state.emotion=Emotion.NEUTRAL; self.state.expression='🙂'; self.state.speech='Tôi đã dừng.'
        elif any(w in t for w in ('vui','kể chuyện','joke')):
            self.state.emotion=Emotion.HAPPY; self.state.expression='😊'; self.state.action='face_smile'; self.state.speech='Tôi đang ở trạng thái vui vẻ!'
        else:
            self.state.emotion=Emotion.CONFUSED; self.state.expression='🤔'; self.state.action='ask_clarification'; self.state.speech='Tôi chưa hiểu lệnh này. Bạn hãy diễn đạt lại nhé.'
            return {'accepted':False,'reason':'Không có hành động tương ứng trong danh sách an toàn.','state':asdict(self.state)}
        self.state.mode='interactive'
        return {'accepted':True,'state':asdict(self.state)}
