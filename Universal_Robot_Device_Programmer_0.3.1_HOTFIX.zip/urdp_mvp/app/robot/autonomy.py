"""Safety-gated autonomy supervisor. Current navigation output is simulation-only."""
from dataclasses import dataclass, asdict
import time
@dataclass
class AutonomyState:
    enabled: bool=False
    mode: str='manual'
    reason: str='Chưa bật tự động.'
    last_sensor_at: float=0.0
    estop: bool=False

class AutonomySupervisor:
    def __init__(self): self.state=AutonomyState()
    def sensor_heartbeat(self): self.state.last_sensor_at=time.time(); return asdict(self.state)
    def enable(self, hardware_estop=False, simulation=True):
        if self.state.estop: return {'accepted':False,'reason':'E-stop đang khóa; cần reset có chủ đích.','state':asdict(self.state)}
        if not simulation and not hardware_estop: return {'accepted':False,'reason':'Thiếu xác nhận hardwired E-stop; từ chối bật chuyển động thật.','state':asdict(self.state)}
        if not simulation and time.time()-self.state.last_sensor_at>1.0: return {'accepted':False,'reason':'Dữ liệu cảm biến quá hạn (>1 giây).','state':asdict(self.state)}
        self.state.enabled=True; self.state.mode='simulation' if simulation else 'supervised'; self.state.reason='Tự động đã bật trong chế độ '+self.state.mode+'.'
        return {'accepted':True,'state':asdict(self.state)}
    def stop(self): self.state.enabled=False; self.state.estop=True; self.state.mode='emergency-stop'; self.state.reason='Đã khóa lệnh tự động.'; return asdict(self.state)
    def reset(self): self.state=AutonomyState(); return asdict(self.state)
