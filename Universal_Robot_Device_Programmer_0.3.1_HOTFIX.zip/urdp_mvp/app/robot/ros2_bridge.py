"""Optional ROS 2 bridge boundary. ROS 2 is not imported by the core process."""
import importlib.util

def status():
    return {'available':importlib.util.find_spec('rclpy') is not None,
            'topics':['/cmd_vel','/odom','/scan','/camera/image_raw'],
            'note':'Cầu nối ROS 2 cần cài ROS 2 tương thích trên máy robot và cấu hình DDS/network.'}
