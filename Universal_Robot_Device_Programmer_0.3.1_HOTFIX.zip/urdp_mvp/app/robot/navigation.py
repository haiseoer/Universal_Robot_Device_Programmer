"""Grid-based A* planner for simulation and map-based prototypes.
Not a substitute for SLAM, localization, obstacle sensors or a certified safety controller.
"""
from heapq import heappush, heappop

def astar(grid, start, goal):
    if not grid or not grid[0]: raise ValueError('Bản đồ trống.')
    h,w=len(grid),len(grid[0])
    for p in (start,goal):
        if len(p)!=2 or not (0<=p[0]<h and 0<=p[1]<w): raise ValueError('Tọa độ ngoài bản đồ.')
        if grid[p[0]][p[1]]: raise ValueError('Điểm bắt đầu/đích nằm trên vật cản.')
    q=[(0,start)]; came={}; cost={start:0}
    while q:
        _,cur=heappop(q)
        if cur==goal:
            path=[cur]
            while cur in came: cur=came[cur]; path.append(cur)
            return list(reversed(path))
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            nxt=(cur[0]+dr,cur[1]+dc)
            if not(0<=nxt[0]<h and 0<=nxt[1]<w) or grid[nxt[0]][nxt[1]]: continue
            nc=cost[cur]+1
            if nc<cost.get(nxt,10**9):
                cost[nxt]=nc; came[nxt]=cur
                heappush(q,(nc+abs(goal[0]-nxt[0])+abs(goal[1]-nxt[1]),nxt))
    return []
