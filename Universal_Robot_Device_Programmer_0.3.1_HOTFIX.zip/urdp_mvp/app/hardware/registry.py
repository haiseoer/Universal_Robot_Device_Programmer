"""Hardware adapter discovery. Adapters describe capabilities; only explicitly enabled
and locally installed toolchains may execute flashing operations.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
import json, shutil

ROOT = Path(__file__).resolve().parent / 'adapters'
@dataclass
class Adapter:
    id: str
    name: str
    family: str
    status: str
    interfaces: list
    artifacts: list
    tool: str | None = None
    notes: str = ''

def list_adapters():
    found=[]
    for p in sorted(ROOT.glob('*.json')):
        try:
            d=json.loads(p.read_text(encoding='utf-8'))
            tool=d.get('tool')
            d['tool_available']=bool(tool and shutil.which(tool))
            found.append(d)
        except Exception: continue
    return found

def get_adapter(adapter_id):
    return next((x for x in list_adapters() if x['id']==adapter_id), None)
