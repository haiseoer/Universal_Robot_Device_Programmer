"""Verify a remotely supplied update manifest using a pinned Ed25519 public key.
Manifest JSON fields: version, url, sha256, signature. Signature is over the exact
UTF-8 bytes of canonical JSON {version,url,sha256}. Only HTTPS URLs are accepted.
This checks metadata/integrity; it does not silently install or flash firmware.
"""
import base64, hashlib, json, os
from urllib.parse import urlparse
from urllib.request import Request, urlopen

class UpdateError(ValueError): pass

def canonical_payload(version, url, sha256):
    return json.dumps({'version':version,'url':url,'sha256':sha256}, separators=(',', ':'), sort_keys=True).encode()

def verify_manifest(data: dict, public_key_b64: str | None = None):
    key = public_key_b64 or os.getenv('URDP_UPDATE_PUBLIC_KEY','')
    if not key: raise UpdateError('Chưa cấu hình khóa công khai Ed25519 của nhà phát hành.')
    url = data.get('url','')
    if urlparse(url).scheme != 'https': raise UpdateError('URL cập nhật bắt buộc dùng HTTPS.')
    digest = data.get('sha256','').lower()
    if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest): raise UpdateError('SHA-256 không hợp lệ.')
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(key, validate=True))
        pub.verify(base64.b64decode(data['signature'], validate=True), canonical_payload(data['version'], url, digest))
    except UpdateError: raise
    except Exception as e: raise UpdateError('Chữ ký cập nhật không hợp lệ hoặc thiếu thư viện cryptography.') from e
    return {'verified':True,'version':data['version'],'url':url,'sha256':digest}

def download_verified(info, destination):
    req=Request(info['url'], headers={'User-Agent':'URDP-Updater/0.2.0'})
    with urlopen(req, timeout=30) as response:
        if response.status != 200: raise UpdateError('Máy chủ cập nhật trả về lỗi.')
        blob=response.read(100*1024*1024+1)
    if len(blob)>100*1024*1024: raise UpdateError('Gói cập nhật vượt quá giới hạn 100 MB.')
    if hashlib.sha256(blob).hexdigest()!=info['sha256']: raise UpdateError('SHA-256 không khớp; đã từ chối gói cập nhật.')
    with open(destination,'wb') as f: f.write(blob)
    return {'downloaded':True,'bytes':len(blob),'path':str(destination)}
