"""Privacy-first image inspection. Uploads are processed in memory and not persisted."""
def inspect_image(blob: bytes):
    if not blob or len(blob)>8*1024*1024: raise ValueError('Ảnh trống hoặc vượt giới hạn 8 MB.')
    try:
        from PIL import Image
        import io
        im=Image.open(io.BytesIO(blob)); im.verify()
        im=Image.open(io.BytesIO(blob))
        return {'accepted':True,'format':im.format,'width':im.width,'height':im.height,'mode':im.mode,
                'analysis':'Đã xác thực ảnh. Nhận diện vật thể/định vị cần model vision được cấu hình riêng.'}
    except ImportError:
        return {'accepted':True,'bytes':len(blob),'analysis':'Đã nhận dữ liệu ảnh; cài Pillow để xác thực định dạng và kích thước.'}
    except Exception as e: raise ValueError('Không đọc được ảnh: '+str(e)[:160])
