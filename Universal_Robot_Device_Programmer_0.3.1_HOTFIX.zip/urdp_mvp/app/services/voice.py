"""Voice capability metadata. Actual capture/TTS runs in the client for privacy."""
def capabilities():
    return {'speech_recognition':'browser-web-speech-api','text_to_speech':'browser-speech-synthesis','server_audio_storage':False,
            'notes':'Phụ thuộc trình duyệt, hệ điều hành, ngôn ngữ và quyền microphone; không phải engine offline đồng nhất.'}
