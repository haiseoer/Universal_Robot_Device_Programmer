#define MyAppName "Universal Robot & Device Programmer"
#define MyAppVersion "0.1.0"
[Setup]
AppId={{A7F7F032-97B0-4E3C-9D2C-000000000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Universal Robot & Device Programmer
DefaultGroupName={#MyAppName}
OutputDir=..\installer-output
OutputBaseFilename=URDP-Setup-0.1.0
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=lowest
[Files]
Source: "..\dist\UniversalRobotDeviceProgrammer\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
[Icons]
Name: "{group}\Universal Robot & Device Programmer"; Filename: "{app}\UniversalRobotDeviceProgrammer.exe"
Name: "{autodesktop}\Universal Robot & Device Programmer"; Filename: "{app}\UniversalRobotDeviceProgrammer.exe"
[Run]
Filename: "{app}\UniversalRobotDeviceProgrammer.exe"; Description: "Launch URDP"; Flags: postinstall nowait skipifsilent
